# Default settings for the app override in your settings.py
from django.conf import settings
import os

APP_PATH = os.path.abspath(os.path.split(__file__)[0])
LOG_FILES_DIR = getattr(
    settings,
    'LOG_FILES_DIR',
    '/ESSArch/log'
)
LOG_FILES_RE = getattr(
    settings,
    'LOG_FILES_RE',
    #'(?P<date>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\s\[(?P<type>[A-Z]+)\]\s(?P<message>.+)'
    '(?P<message>^.*$)'
)

LOG_FILES_NAME_1 = getattr(
    settings,
    'LOG_FILES_NAME_1',
    ['controlarea','ESSArch_db','storagemaintenance']
)
LOG_FILES_RE_1 = getattr(
    settings,
    'LOG_FILES_RE_1',
    '(?P<date>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\s(?P<type>[A-Z]+)\s(?P<module>[a-zA-Z]+)\s(?P<process>[0-9]+)\s(?P<thread>[0-9]+)\s(?P<message>.+)'
)
LOG_FILES_NAME_2 = getattr(
    settings,
    'LOG_FILES_NAME_2',
    ['AccessEngine','AIPChecksum','AIPCreator','AIPPurge','AIPValidate','AIPWriter','AIPWriter_2','db_sync_ais','ESSlogging','FTPServer','IOEngine_2','IOEngine','SIPReceiver','SIPRemove','SIPValidateAIS','SIPValidateApproval','SIPValidateFormat','TLD','storageLogistics']
)
LOG_FILES_RE_2 = getattr(
    settings,
    'LOG_FILES_RE_2',
    '(?P<date>\d{2} [a-zA-Z]+ \d{4} \d{2}:\d{2}:\d{2})\s(?P<type>[\/\-\w]+)\s(?P<message>.+)'
)
LOG_FILES_NAME_3 = getattr(
    settings,
    'LOG_FILES_NAME_3',
    ['Tools','ESSArch']
)
LOG_FILES_RE_3 = getattr(
    settings,
    'LOG_FILES_RE_3',
    '(?P<type>[A-Z]+)\s(?P<date>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\s(?P<module>[a-zA-Z]+)\s(?P<process>[0-9]+)\s(?P<thread>[0-9]+)\s(?P<message>.+)'
)
LOG_FILES_NAME_4 = getattr(
    settings,
    'LOG_FILES_NAME_4',
    []
)
LOG_FILES_RE_4 = getattr(
    settings,
    'LOG_FILES_RE_4',
    ''
)
LOG_FILES_NAME_5 = getattr(
    settings,
    'LOG_FILES_NAME_5',
    []
)
LOG_FILES_RE_5 = getattr(
    settings,
    'LOG_FILES_RE_5',
    ''
)

LOG_FILES_PAGINATE_LINES = getattr(settings, 'LOG_FILES_PAGINATE_LINES', 20)

PAGINATOR_PAGE_SEPARATOR = getattr(settings, 'PAGINATOR_PAGE_SEPARATOR', '...')

__all__ = ['LOG_FILES_DIR', 'LOG_FILES_RE', 'LOG_FILES_PAGINATE_LINES', 'LOG_FILES_NAME_1', 'LOG_FILES_RE_1', 'LOG_FILES_NAME_2', 'LOG_FILES_RE_2', 'LOG_FILES_NAME_3', 'LOG_FILES_RE_3', 'LOG_FILES_NAME_4', 'LOG_FILES_RE_4', 'LOG_FILES_NAME_5', 'LOG_FILES_RE_5']
